/**
 * charts.js - Funkcje do generowania wykresów
 * Bezpieczna implementacja bez inline skryptów
 */

'use strict';

// Funkcja generująca wykresy będzie wykorzystywana przez main.js
// Tutaj mogą być dodane funkcje specyficzne dla wykresów jeśli potrzebne

console.log('Charts.js loaded successfully');
